#!/usr/bin/env python3
"""
Zero-Knowledge(ish) Voting Protocol Prototype (Hackathon)

Threat model / intent (hackathon-level):
- Prevent double-voting without storing Aadhaar numbers.
- Never store any link between a voter (or their nullifier hash) and their vote.
- Persist only aggregated masked totals + a nullifier set.

Why this satisfies "Zero-Knowledge" and "No Link Stored":
- We store only:
    1) masked_sum: sum of (vote_encoding + noise) mod PRIME
    2) noise_sum: sum of noise mod PRIME
    3) nullifier_list: salted SHA-256 hashes of Aadhaar numbers (to block re-vote)
- The vote itself is *never* written alongside any identifier or hash.
- Anyone reading the database can see only a single aggregate integer (masked_sum),
  which is information-theoretically blinded by random noise until the admin performs
  the subtraction masked_sum - noise_sum (mod PRIME) at final tally time.

NOTE: This is a prototype. Real ZK voting uses proper ZK proofs, credentials, and
distributed trust assumptions. Here we demonstrate the "no link stored" property
with additive masking and a nullifier set.
"""

from __future__ import annotations

import hashlib
import os
import secrets
import sys
from dataclasses import dataclass
from typing import List, Set, Tuple


# Large Mersenne prime for modular arithmetic: 2^61 - 1
PRIME: int = (1 << 61) - 1

# Power-of-100 encoding for 5 parties (each party count fits in 0..99).
PARTY_BASE: int = 100
NUM_PARTIES: int = 5
PARTY_ENCODINGS: Tuple[int, ...] = tuple(PARTY_BASE**i for i in range(NUM_PARTIES))

# Persistence file (required by prompt)
DB_PATH: str = "database.txt"

# Hardcoded admin password (required by prompt)
ADMIN_PASSWORD: str = "admin123"

# Salt for Aadhaar nullifier hashing.
# - We never store Aadhaar itself.
# - Salt prevents simple rainbow-table lookups for common/known numbers.
# In a real system you'd store this securely, rotate carefully, and/or use a KDF.
NULLIFIER_SALT: bytes = b"hackathon-demo-salt-v1"


@dataclass(frozen=True)
class DatabaseState:
    masked_sum: int
    noise_sum: int
    nullifiers: Set[str]


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def aadhaar_to_nullifier(aadhaar: str) -> str:
    """
    Convert Aadhaar to a salted SHA-256 hash (nullifier).
    The raw Aadhaar is never persisted.
    """
    normalized = "".join(ch for ch in aadhaar.strip() if ch.isdigit())
    if len(normalized) < 8:
        # Minimal sanity check for demo; do not over-validate in hackathons.
        raise ValueError("Aadhaar must contain digits (at least 8 for this demo).")
    return _sha256_hex(NULLIFIER_SALT + normalized.encode("utf-8"))


def init_db_if_missing(path: str = DB_PATH) -> None:
    """
    Initialize database file if it doesn't exist.
    Format: masked_sum,noise_sum,nullifier_list
    """
    if os.path.exists(path):
        return
    with open(path, "w", encoding="utf-8") as f:
        f.write("0,0,\n")


def load_db(path: str = DB_PATH) -> DatabaseState:
    init_db_if_missing(path)
    raw = ""
    with open(path, "r", encoding="utf-8") as f:
        raw = f.read().strip("\n")

    # Accept either blank file or strict format; re-initialize safely if empty.
    if not raw.strip():
        return DatabaseState(masked_sum=0, noise_sum=0, nullifiers=set())

    parts = raw.split(",", maxsplit=2)
    if len(parts) != 3:
        raise ValueError("Corrupt database.txt format. Expected: masked_sum,noise_sum,nullifier_list")

    masked_sum_str, noise_sum_str, nullifier_list_str = parts
    masked_sum = int(masked_sum_str) % PRIME
    noise_sum = int(noise_sum_str) % PRIME

    nullifiers: Set[str] = set()
    if nullifier_list_str.strip():
        for item in nullifier_list_str.split("|"):
            item = item.strip()
            if item:
                nullifiers.add(item)

    return DatabaseState(masked_sum=masked_sum, noise_sum=noise_sum, nullifiers=nullifiers)


def save_db(state: DatabaseState, path: str = DB_PATH) -> None:
    nullifier_list = "|".join(sorted(state.nullifiers))
    with open(path, "w", encoding="utf-8") as f:
        f.write(f"{state.masked_sum},{state.noise_sum},{nullifier_list}\n")


def party_choice_to_encoding(choice: int) -> int:
    if choice < 1 or choice > NUM_PARTIES:
        raise ValueError(f"Party choice must be 1-{NUM_PARTIES}.")
    return PARTY_ENCODINGS[choice - 1]


def cast_vote() -> None:
    state = load_db()

    aadhaar = input("Enter Aadhaar number: ").strip()
    try:
        nullifier = aadhaar_to_nullifier(aadhaar)
    except ValueError as e:
        print(f"Invalid Aadhaar: {e}")
        return

    if nullifier in state.nullifiers:
        print("Vote rejected: this Aadhaar has already voted (nullifier exists).")
        return

    print("Choose a party:")
    print("1) Party 1")
    print("2) Party 2")
    print("3) Party 3")
    print("4) Party 4")
    print("5) Party 5")

    try:
        choice = int(input("Enter party number (1-5): ").strip())
        vote_value = party_choice_to_encoding(choice)
    except Exception:
        print("Invalid party choice.")
        return

    # Cryptographically secure random noise (per vote)
    noise = secrets.randbelow(PRIME)

    # Blinded vote. Only the blinded aggregate is stored.
    blinded_vote = (vote_value + noise) % PRIME

    new_masked_sum = (state.masked_sum + blinded_vote) % PRIME
    new_noise_sum = (state.noise_sum + noise) % PRIME
    new_nullifiers = set(state.nullifiers)
    new_nullifiers.add(nullifier)

    save_db(DatabaseState(masked_sum=new_masked_sum, noise_sum=new_noise_sum, nullifiers=new_nullifiers))

    print("Vote cast successfully.")
    print("Privacy note: your vote was masked with random noise and stored only as a global aggregate.")


def generate_proof_of_integrity() -> None:
    state = load_db()
    proof = _sha256_hex(str(state.masked_sum).encode("utf-8"))
    print("Proof of Integrity (SHA-256 of masked_sum):")
    print(proof)
    print("Anyone can recompute this from database.txt to detect tampering with masked_sum.")


def decode_counts(total: int) -> List[int]:
    """
    Decode per-party counts from the base-100 packed integer.
    Each party count occupies two decimal digits in base-100 (0..99).
    """
    counts: List[int] = []
    for i in range(NUM_PARTIES):
        counts.append((total // (PARTY_BASE**i)) % PARTY_BASE)
    return counts


def final_tally_admin_only() -> None:
    password = input("Admin password: ").strip()
    if password != ADMIN_PASSWORD:
        print("Access denied.")
        return

    state = load_db()

    # Unmask the aggregate.
    # This reveals only the final packed tally, not any voter-to-vote relationship.
    unmasked_total = (state.masked_sum - state.noise_sum) % PRIME
    counts = decode_counts(unmasked_total)

    print("\nFinal Tally (decoded from packed total):")
    for i, c in enumerate(counts, start=1):
        print(f"- Party {i}: {c} votes")

    winner_party = max(range(1, NUM_PARTIES + 1), key=lambda p: counts[p - 1])
    print(f"\nWinner: Party {winner_party}")

    # Safety notice: if any party exceeds 99 votes, base-100 digits would carry and overlap.
    if any(c >= 100 for c in counts):
        print("\nWARNING: Count overflow detected (>=100). Encoding assumes max 99 votes/party.")


def menu() -> None:
    init_db_if_missing()
    while True:
        print("\n=== Zero-Knowledge Voting Protocol (Prototype) ===")
        print("1) Cast Vote")
        print("2) Generate Proof of Integrity")
        print("3) Final Tally (Admin Only)")
        print("4) Exit")

        choice = input("Select an option: ").strip()
        if choice == "1":
            cast_vote()
        elif choice == "2":
            generate_proof_of_integrity()
        elif choice == "3":
            final_tally_admin_only()
        elif choice == "4":
            print("Goodbye.")
            return
        else:
            print("Invalid option.")


def main() -> None:
    try:
        menu()
    except KeyboardInterrupt:
        print("\nInterrupted.")
        sys.exit(1)


if __name__ == "__main__":
    main()

