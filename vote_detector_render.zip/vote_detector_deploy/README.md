# Zero-Knowledge Voting Protocol (Python Prototype)

This repo contains:

- `zk_voting.py`: console prototype
- `app.py` + `templates/`: Flask + Tailwind “Cyber‑Vault” web prototype (verifiable audit + admin tally)

Both prototypes implement the same core idea:

- Prevents double-voting using **Aadhaar nullifiers** (raw Aadhaar is never stored).
- Stores **no link** between a user (or their hash) and their vote.
- Stores only **masked aggregate totals** using cryptographically secure randomness.

## Run (Web Prototype)

```bash
python3 -m venv .venv
. .venv/bin/activate
pip install -r requirements.txt

# optional (recommended): set secrets
export VOTING_PEPPER='change-me-long-random'
export FLASK_SECRET_KEY='change-me-long-random'

python app.py
```

Then open `http://127.0.0.1:5000`.

## Run (Console Prototype)

```bash
python3 zk_voting.py
```

## Persistence

The app uses `database.txt` in the same directory. If missing, it is initialized as:

```
masked_sum|noise_sum|hash_list
```

Where `hash_list` is a `|`-separated set of Aadhaar nullifiers (HMAC in the web app).

