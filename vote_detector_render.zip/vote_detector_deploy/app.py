#!/usr/bin/env python3
"""
Zero‑Knowledge Verifiable Voting System (Web Prototype)
======================================================
notes (security-first architecture):
- Flat-file DB: `database.txt` with structure `masked_sum|noise_sum|hash_list`
  - `masked_sum`: Σ(vote_encoding + noise) mod PRIME
  - `noise_sum` : Σ(noise) mod PRIME
  - `hash_list` : '|' separated list of Aadhaar nullifiers (HMAC-SHA256)

- "Zero-Knowledge" property (hackathon framing):
  - The server never stores any (voter -> vote) mapping.
  - The only persistent vote data is an *aggregate* masked sum.
  - Even an internal leak of the database reveals only:
      - an unreadable masked aggregate integer
      - a nullifier set (to stop re-voting) that does not encode vote choice
  - Only the aggregate is ever "decrypted" (unmasked) by computing:
      total = (masked_sum - noise_sum) mod PRIME
    which yields a packed base-100 tally. No per-user votes can be reconstructed.

- Aadhaar privacy:
  - Raw Aadhaar is never persisted.
  - We derive a nullifier using HMAC with a server-side secret pepper. This prevents
    rainbow-table attacks against the (structured) Aadhaar number space, even if the
    database leaks.

- Integrity / auditability:
  - Public audit endpoint exposes SHA-256 hash of the entire database file.
    Tampering changes the hash.

This remains a prototype: real ZK systems would use credentials + ZK proofs and
distributed trust. Here we demonstrate strong "no link stored" and leak resistance.
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import secrets
import time
from dataclasses import dataclass
from typing import List, Set, Tuple

from flask import (
    Flask,
    Response,
    flash,
    redirect,
    render_template,
    request,
    send_file,
    session,
    url_for,
)


# -------------------------
# Cryptographic Parameters
# -------------------------

# 64-bit Mersenne prime field (fits safely in Python int and keeps values bounded)
PRIME: int = (1 << 61) - 1

# 5 parties; "power of 100" packed encoding (up to 99 votes per party)
PARTY_BASE: int = 100
NUM_PARTIES: int = 5
PARTY_ENCODINGS: Tuple[int, ...] = tuple(PARTY_BASE**i for i in range(NUM_PARTIES))

# Admin dashboard password (demo requirement)
ADMIN_PASSWORD: str = "admin123"

# Flat-file DB
DB_PATH: str = os.environ.get("DB_PATH", os.path.join(os.path.dirname(os.path.abspath(__file__)), "database.txt"))


def _env_bytes(name: str, default: bytes) -> bytes:
    v = os.environ.get(name, "")
    if not v:
        return default
    return v.encode("utf-8")


# Server-side HMAC pepper (set in env for production-ish demo)
# Example: export VOTING_PEPPER='change-me-long-random'
HMAC_PEPPER: bytes = _env_bytes("VOTING_PEPPER", b"demo-pepper-change-me")


# -------------------------
# Persistence (flat-file DB)
# -------------------------

@dataclass(frozen=True)
class DBState:
    masked_sum: int
    noise_sum: int
    nullifiers: Set[str]


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def init_db_if_missing() -> None:
    """
    Required structure: masked_sum|noise_sum|hash_list
    """
    if os.path.exists(DB_PATH):
        # If the file exists but is empty, initialize it.
        try:
            if os.path.getsize(DB_PATH) == 0:
                with open(DB_PATH, "w", encoding="utf-8") as f:
                    f.write("0|0|\n")
        except OSError:
            pass
        return
    with open(DB_PATH, "w", encoding="utf-8") as f:
        f.write("0|0|\n")


def _parse_db_line(line: str) -> DBState:
    """
    Accepts the required `|` format and also tolerates the earlier comma format
    (to avoid breaking local demos if `database.txt` already exists).
    """
    raw = line.strip("\n").strip()
    if not raw:
        return DBState(masked_sum=0, noise_sum=0, nullifiers=set())

    if "|" in raw:
        parts = raw.split("|", maxsplit=2)
    else:
        parts = raw.split(",", maxsplit=2)

    if len(parts) != 3:
        raise ValueError("Corrupt database.txt: expected `masked_sum|noise_sum|hash_list`")

    masked_sum = int(parts[0]) % PRIME
    noise_sum = int(parts[1]) % PRIME
    hash_list_str = parts[2].strip()

    nullifiers: Set[str] = set()
    if hash_list_str:
        for item in hash_list_str.split("|"):
            item = item.strip()
            if item:
                nullifiers.add(item)

    return DBState(masked_sum=masked_sum, noise_sum=noise_sum, nullifiers=nullifiers)


def _serialize_state(state: DBState) -> str:
    hash_list = "|".join(sorted(state.nullifiers))
    return f"{state.masked_sum}|{state.noise_sum}|{hash_list}\n"


def _locked_read_modify_write(update_fn):
    """
    Best-effort file locking for macOS/Linux to prevent lost updates.
    Uses an atomic write (write temp file then replace).
    """
    import fcntl  # Unix-only; fine for darwin (user OS)

    init_db_if_missing()
    with open(DB_PATH, "r+", encoding="utf-8") as f:
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            current = f.read()
            state = _parse_db_line(current)
            new_state = update_fn(state)
            data = _serialize_state(new_state)
            tmp = DB_PATH + ".tmp"
            with open(tmp, "w", encoding="utf-8") as tf:
                tf.write(data)
                tf.flush()
                os.fsync(tf.fileno())
            os.replace(tmp, DB_PATH)
            return new_state
        finally:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            except OSError:
                pass


def load_state() -> DBState:
    init_db_if_missing()
    with open(DB_PATH, "r", encoding="utf-8") as f:
        return _parse_db_line(f.read())


def database_file_hash() -> str:
    init_db_if_missing()
    with open(DB_PATH, "rb") as f:
        return _sha256_hex(f.read())


# -------------------------
# Identity (Aadhaar nullifier)
# -------------------------

def _normalize_aadhaar(aadhaar: str) -> str:
    """
    Hackathon UX: accept registration even for short / non-standard inputs.

    - If digits exist, we use only digits (common Aadhaar entry style).
    - If no digits exist, we fall back to the raw trimmed string.
    - We only require non-empty input so "register anyway" works.
    """
    raw = aadhaar.strip()
    if not raw:
        raise ValueError("Please enter an Aadhaar (non-empty).")
    digits = "".join(ch for ch in raw if ch.isdigit())
    return digits if digits else raw


def aadhaar_nullifier_hmac(aadhaar: str) -> str:
    """
    Aadhaar nullifier = HMAC_SHA256(pepper, normalized_aadhaar).
    - Pepper is server-side secret (prevents rainbow table attacks on Aadhaar space).
    - Only the nullifier is persisted; raw Aadhaar is never stored.
    """
    digits = _normalize_aadhaar(aadhaar)
    mac = hmac.new(HMAC_PEPPER, digits.encode("utf-8"), hashlib.sha256)
    return mac.hexdigest()

def mask_aadhaar_preview(aadhaar: str) -> str:
    """
    Returns a UX-only masked preview like XXXX-XXXX-1234.
    This is never written to `database.txt` and is not used for security decisions.
    """
    digits = _normalize_aadhaar(aadhaar)
    last4 = digits[-4:]
    return f"XXXX-XXXX-{last4}"


# -------------------------
# Voting math (masking + tally)
# -------------------------

def party_encoding(party_id: int) -> int:
    if party_id < 1 or party_id > NUM_PARTIES:
        raise ValueError("Invalid party.")
    return PARTY_ENCODINGS[party_id - 1]


def decode_counts(packed_total: int) -> List[int]:
    counts: List[int] = []
    for i in range(NUM_PARTIES):
        counts.append((packed_total // (PARTY_BASE**i)) % PARTY_BASE)
    return counts


def cast_masked_vote(nullifier: str, party_id: int) -> None:
    """
    Additive homomorphic masking:
      blinded_vote = (vote_value + noise) mod PRIME
      masked_sum  += blinded_vote
      noise_sum   += noise

    Security properties (against internal data leaks):
    - Persisted storage never contains a per-voter vote.
    - Even with DB exfiltration, an attacker sees only an aggregate masked value.
    - Nullifier list prevents double-voting but is independent of the vote value.
    """

    vote_value = party_encoding(party_id)
    noise = secrets.randbelow(PRIME)
    blinded_vote = (vote_value + noise) % PRIME

    def updater(state: DBState) -> DBState:
        if nullifier in state.nullifiers:
            raise ValueError("Already voted.")
        new_nullifiers = set(state.nullifiers)
        new_nullifiers.add(nullifier)
        return DBState(
            masked_sum=(state.masked_sum + blinded_vote) % PRIME,
            noise_sum=(state.noise_sum + noise) % PRIME,
            nullifiers=new_nullifiers,
        )

    try:
        _locked_read_modify_write(updater)
    finally:
        # Volatile memory hygiene (best-effort in Python):
        # overwrite and delete references so values don't accidentally linger.
        vote_value = 0
        noise = 0
        blinded_vote = 0
        try:
            del vote_value, noise, blinded_vote
        except UnboundLocalError:
            pass


def final_unmasked_tally() -> Tuple[List[int], int]:
    state = load_state()
    packed_total = (state.masked_sum - state.noise_sum) % PRIME
    return decode_counts(packed_total), packed_total


# -------------------------
# Flask app
# -------------------------

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET_KEY", secrets.token_hex(32))
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
)


@app.get("/")
def index():
    return render_template("index.html")


@app.route("/register", methods=["GET", "POST"])
def register():
    if request.method == "POST":
        aadhaar = request.form.get("aadhaar_raw", "")
        try:
            aadhaar_preview = mask_aadhaar_preview(aadhaar)
            nullifier = aadhaar_nullifier_hmac(aadhaar)
        except ValueError as e:
            flash(str(e), "error")
            return redirect(url_for("register"))
        finally:
            # Best-effort overwrite of request-local sensitive string:
            aadhaar = "0" * max(0, len(aadhaar))

        # Store only nullifier in session (client-side cookie is signed).
        # We still do NOT persist any (nullifier -> vote) mapping server-side.
        session["nullifier"] = nullifier
        session["aadhaar_preview"] = aadhaar_preview
        flash(f"Registered {aadhaar_preview}. You can now cast exactly one vote.", "ok")
        return redirect(url_for("vote"))

    return render_template(
        "register.html",
        has_nullifier=bool(session.get("nullifier")),
        aadhaar_preview=session.get("aadhaar_preview"),
    )


@app.route("/vote", methods=["GET", "POST"])
def vote():
    nullifier = session.get("nullifier")
    if not nullifier:
        flash("Please register your Aadhaar before voting.", "error")
        return redirect(url_for("register"))

    if request.method == "POST":
        party = request.form.get("party", "").strip()
        try:
            party_id = int(party)
            # simulate crypto work for UX (loading state on frontend)
            time.sleep(0.4)
            cast_masked_vote(nullifier, party_id)
        except ValueError as e:
            msg = str(e) if str(e) else "Invalid request."
            flash(msg, "error")
            return redirect(url_for("vote"))
        except Exception:
            flash("Vote failed due to an internal error.", "error")
            return redirect(url_for("vote"))
        else:
            flash("Vote accepted and masked into the global aggregate.", "ok")
            # Optional: clear nullifier from session to reduce client-side exposure.
            # Double-voting is still blocked by the server-side nullifier list.
            session.pop("nullifier", None)
            return redirect(url_for("audit"))

    return render_template(
        "vote.html",
        aadhaar_preview=session.get("aadhaar_preview"),
        parties=[
            {"id": 1, "name": "Party 1", "icon": "⚡"},
            {"id": 2, "name": "Party 2", "icon": "🛡"},
            {"id": 3, "name": "Party 3", "icon": "🧬"},
            {"id": 4, "name": "Party 4", "icon": "🛰"},
            {"id": 5, "name": "Party 5", "icon": "🔷"},
        ],
    )


@app.get("/audit")
def audit():
    state = load_state()
    db_hash = database_file_hash()
    masked_sum_hash = _sha256_hex(str(state.masked_sum).encode("utf-8"))
    return render_template(
        "audit.html",
        db_hash=db_hash,
        masked_sum_hash=masked_sum_hash,
        masked_sum=state.masked_sum,
        total_nullifiers=len(state.nullifiers),
        field_prime=PRIME,
    )


@app.route("/admin", methods=["GET", "POST"])
def admin():
    if request.method == "POST":
        password = request.form.get("password", "")
        if password != ADMIN_PASSWORD:
            flash("Invalid decryption key.", "error")
            return redirect(url_for("admin"))
        session["is_admin"] = True
        return redirect(url_for("admin_dashboard"))

    return render_template("admin.html", mode="login")


@app.get("/admin/dashboard")
def admin_dashboard():
    if not session.get("is_admin"):
        flash("Admin access required.", "error")
        return redirect(url_for("admin"))

    counts, packed_total = final_unmasked_tally()
    winner = 1 + max(range(NUM_PARTIES), key=lambda i: counts[i]) if counts else 1
    return render_template(
        "admin.html",
        mode="dashboard",
        counts=counts,
        packed_total=packed_total,
        winner=winner,
        counts_json=json.dumps(counts),
    )


@app.post("/admin/logout")
def admin_logout():
    session.pop("is_admin", None)
    flash("Admin session cleared.", "ok")
    return redirect(url_for("index"))


@app.get("/admin/certificate")
def admin_certificate():
    if not session.get("is_admin"):
        flash("Admin access required.", "error")
        return redirect(url_for("admin"))

    state = load_state()
    counts, _packed_total = final_unmasked_tally()
    nullifiers_hash = _sha256_hex("|".join(sorted(state.nullifiers)).encode("utf-8"))
    db_hash = database_file_hash()

    lines = [
        "ZERO‑KNOWLEDGE VOTING — INTEGRITY CERTIFICATE",
        "",
        f"Database SHA‑256: {db_hash}",
        f"Final Masked Sum: {state.masked_sum}",
        f"Nullifier List Hash (SHA‑256): {nullifiers_hash}",
        "",
        "Final Tally (decoded from packed total):",
    ]
    for i, c in enumerate(counts, start=1):
        lines.append(f"Party {i}: {c}")
    winner = 1 + max(range(NUM_PARTIES), key=lambda i: counts[i]) if counts else 1
    lines.extend(["", f"Winner: Party {winner}", ""])

    content = "\n".join(lines).encode("utf-8")
    filename = "integrity_certificate.txt"
    return Response(
        content,
        headers={
            "Content-Type": "text/plain; charset=utf-8",
            "Content-Disposition": f'attachment; filename="{filename}"',
        },
    )


if __name__ == "__main__":
    init_db_if_missing()
    port = int(os.environ.get("PORT", "5001"))
    app.run(host="127.0.0.1", port=port, debug=True)

